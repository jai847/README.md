import cv2
import numpy as np
video = cv2.VideoCapture(r'C:/Users/jaich/OneDrive/Documents/Desktop/str/story1/Video Project 3.mp4')
img = cv2.imread(r"C:/Users/jaich/OneDrive/Documents/Desktop/028A9392-copy.webp")
cap = cv2.VideoCapture(0)
threshold_value = 100
print("Dimensions of the image:", img.shape)
width = 400
height = 400
dim = (width, height)
resized = cv2.resize(img, dim)
resize = cv2.resize(img, (640, 640))
kernal_1 = 3
ksize = (7, 7)
sigmax = 0
sigmay = 0
min_thresh = 100
max_thresh = 200
print("Dimensions of the resized image:", img.size)
cv2.imshow("window", resized)
kernal = np.ones((5,5), dtype='uint8')
tophat = cv2.morphologyEx(resized, cv2.MORPH_TOPHAT, kernal)
cv2.imshow("Tophat", tophat)
blackhat = cv2.morphologyEx(resized, cv2.MORPH_BLACKHAT, kernal)
cv2.imshow("Blackhat", blackhat)
flip_2 = cv2.flip(resized, -1)
cv2.imshow("Horizontal & vertical:", flip_2)
img = np.zeros(shape=[600,800,3], dtype='uint8')
img.fill(255)
cv2.line(img, (0,0), (150,150), (255,0,0), 2)
pts_polygon = np.array([[100,50],[100,300],[500,50],[500,300]], np.int32)
cv2.polylines(img, [pts_polygon], True, (0,255,0), 3)
row = img.shape[0]
column = img.shape[1]
center = (column/2, row/2)
angle = 180
r = cv2.getRotationMatrix2D(center, angle, 1)
rotate = cv2.warpAffine(img, r, (column, row))
cv2.imshow('Rotated', rotate)
_, binary_threshold = cv2.threshold(rotate, threshold_value, 255, cv2.THRESH_BINARY)
cv2.imshow('Binary Threshold', binary_threshold)
blur = cv2.GaussianBlur(resize, ksize, sigmax)
cv2.imshow('Input', resize)
blur_1 = cv2.medianBlur(resize, kernal_1)
cv2.imshow('output', blur_1)
edges = cv2.Canny(resize, min_thresh, max_thresh)
cv2.imshow('original', resize)
cv2.imshow('Edges', edges)
cv2.waitKey(0)
while video.isOpened():
    ret, frame = video.read()
    if not ret:
        break
    frame = cv2.resize(frame, (800,720))
    cv2.imshow('output', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
video.release()
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
output = cv2.VideoWriter('output.mp4', fourcc, 25.0, (800,720))
video = cv2.VideoCapture(r'C:/Users/jaich/OneDrive/Documents/Desktop/str/story1/Video Project 3.mp4')
while video.isOpened():
    ret, frame = video.read()
    if ret:
        frame = cv2.resize(frame, (800,720))
        output.write(frame)
        cv2.imshow('Frame', frame)
        if cv2.waitKey(10) == ord('s'):
            break
    else:
        break
video.release()
output.release()
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imshow('live', frame)
    if cv2.waitKey(10) == ord('z'):
        break
cap.release()
cv2.destroyAllWindows()