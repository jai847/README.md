import socket
from tkinter import *
def send(listbox, entry):
    message_to_send = entry.get()
    listbox.insert(END, message_to_send)
    entry.delete(0, END)
    client.send(bytes(message_to_send, "utf-8"))
def receive(listbox):
    message_from_client = client.recv(50)
    listbox.insert(END, message_from_client.decode("utf-8"))
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HOST_NAME = socket.gethostname()
PORT = 12345
s.bind((HOST_NAME, PORT))
print(HOST_NAME, PORT)
s.listen(4)
print("Waiting for client...")
client, address = s.accept()
print("Connected to:", address)
window = Tk()
window.title("Server")
entry = Entry(window)
entry.pack(side=BOTTOM)
listbox = Listbox(window)
listbox.pack()
button = Button(window,text="Send",command=lambda: send(listbox, entry))
button.pack(side=BOTTOM)
rbutton = Button(window, text="Receive",command=lambda: receive(listbox))
rbutton.pack(side=BOTTOM)
window.mainloop()
while True:
    message = input("Server: ")
    client.send(bytes(message, "utf-8"))
    message_from_client = client.recv(50)
    print("Client:", message_from_client.decode("utf-8"))
client.close()

