import socket
from tkinter import *
def send(listbox, entry):
    message_to_send = entry.get()
    listbox.insert(END, message_to_send)
    entry.delete(0, END)
    s.send(bytes(message_to_send, "utf-8"))
    receive(listbox)
def receive(listbox):
    message_from_server = s.recv(50)
    listbox.insert(END, message_from_server.decode("utf-8"))
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HOST_NAME = socket.gethostname()
PORT = 12345
s.connect((HOST_NAME, PORT))
print(HOST_NAME, PORT)
window = Tk()
window.title("Client")
entry = Entry(window)
entry.pack(side=BOTTOM)
listbox = Listbox(window)
listbox.pack()
button = Button(window, text="Send",command=lambda: send(listbox, entry))
button.pack(side=BOTTOM)
rbutton = Button(window, text="Receive",command=lambda: receive(listbox))
rbutton.pack(side=BOTTOM)
window.mainloop()
while True:
    message = s.recv(50)
    print("Server:", message.decode("utf-8"))
    message_to_send = input("Client: ")
    s.send(bytes(message_to_send, "utf-8"))
s.close()


