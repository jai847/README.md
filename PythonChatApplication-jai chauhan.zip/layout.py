from tkinter import *
window=TK()
entry=Entry()
entry.pack(side=Bottom)
listbox=Listbox(window)
listbox.pack()
button=Button(window,text='send')
button.pack(side=Buttom)
window.mainloop()