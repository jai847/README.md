import requests
from bs4 import BeautifulSoup
class pricetrack:
    def __init__(self,url):
        self.url = url
        headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0"}
        response = requests.get(url=url,headers=headers)
        self.soup = BeautifulSoup(response.text,"lxml")
    def title(self):
        tit=self.soup.find("h1", class_="v1zwn21l v1zwn26 _1psv1zeb9 _1psv1ze0")
        if tit:
            return tit.text.strip()
        else:
            return "not found"

    def price(self):
          pri=self.soup.find("div", class_="v1zwn21l v1zwn20 _1psv1zeb9 _1psv1ze0",font="default-fk-font-m")
          if pri:
              return pri.text.strip()
          else:
              return "not found"

    def image(self):
        img = self.soup.find("img")
        if img:
            return img.get("src")
        else:
            return "not found"

    def download(self):
        img_url = self.image()
        if img_url != "not found":
            img = requests.get(img_url)
            with open("product.jpg", "wb") as f:
                f.write(img.content)
            print("Downloaded")
    def compare_price(self,target_price):
        pri=self.price()
        if pri !="not found":
            value=float(pri.replace("₹","").replace(",",""))
            if value<=target_price:
                print("price is good,buy it.")
            else:
                print("wait price drop")
        else:
            print("price not found")



urls=["https://www.flipkart.com/apple-iphone-16-pink-128-gb/p/itmc2e910b4d0b1c?pid=MOBH4DQFWJVDRSHM&lid=LSTMOBH4DQFWJVDRSHMAMTBLL&marketplace=FLIPKART&store=tyy%2F4io&srno=b_1_1&otracker=browse&fm=organic&iid=04664123-1f0e-4e31-97da-b0cf75b047fd.MOBH4DQFWJVDRSHM.SEARCH&ppt=None&ppn=None&ssid=yk0uhe7blc0000001785299773405&ov_redirect=true"]
target_price=500000
for url in urls:
    product=pricetrack(url)
    print("Title:",product.title())
    print("price:",product.price())
    print("image:",product.image())
    product.compare_price(target_price)
    product.download()









